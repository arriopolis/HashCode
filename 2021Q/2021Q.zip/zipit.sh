#!/usr/bin/env bash
rm 2021Q.zip
zip 2021Q.zip . -r -x "input/*" -x "output/*"
